readme.txt

Deck1
　High
　　MIDIメッセージ：0x0b, channel=0, Data1=7, Data2=0～127
　　ショートカット：1:マイナス・2:プラス
　Mid
　　MIDIメッセージ：0x0b, channel=0, Data1=6, Data2=0～127
　　ショートカット：Q:マイナス・W:プラス
　Low
　　MIDIメッセージ：0x0b, channel=0, Data1=5, Data2=0～127
　　ショートカット：A:マイナス・S:プラス
　Level(縦フェーダー)
　　MIDIメッセージ：0x0b, channel=0, Data1=4, Data2=0～127
　　ショートカット：Z:マイナス・X:プラス
　Queue
　　MIDIメッセージ：0x0b, channel=0, Data1=3, Data2=0/127

Deck2
　High
　　MIDIメッセージ：0x0b, channel=1, Data1=7, Data2=0～127
　　ショートカット：3:マイナス・4:プラス
　Mid
　　MIDIメッセージ：0x0b, channel=1, Data1=6, Data2=0～127
　　ショートカット：E:マイナス・R:プラス
　Low
　　MIDIメッセージ：0x0b, channel=1, Data1=5, Data2=0～127
　　ショートカット：D:マイナス・F:プラス
　Level(縦フェーダー)
　　MIDIメッセージ：0x0b, channel=1, Data1=4, Data2=0～127
　　ショートカット：C:マイナス・V:プラス
　Queue
　　MIDIメッセージ：0x0b, channel=1, Data1=3, Data2=0/127
